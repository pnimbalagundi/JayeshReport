export const config = {
  baseUrl: 'https://192.168.6.172/security/login',
  username: 'Admin3',
  password: 'P@$$w0rd',
};