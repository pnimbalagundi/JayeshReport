export const login_selectors = {
    loginUsernameEntry: "#Username",
    loginPasswordEntry: "#Password",
    loginButton: ".submitbutton",
    dashboardHeader:'h1:has-text("Dashboard")',
    errorMessage: 'The username or password provided in the request are invalid.',
    logOutLink:'(//span[normalize-space()="Sign Out"])[1]' 
};