import { Before, After, BeforeAll, AfterAll, Status, ITestCaseHookParameter } from '@cucumber/cucumber';
import { chromium, Browser } from '@playwright/test';
import { CustomWorld } from './world';

let browser: Browser;

BeforeAll(async () => {
  console.log('Launching browser...');
  browser = await chromium.launch({ headless: false });
});

Before(async function (this: CustomWorld) {
  console.log('Setting up context and page...');
  this.context! = await browser.newContext({ ignoreHTTPSErrors: true });
  this.page! = await this.context!.newPage();
});

After(async function (this: CustomWorld) {
  console.log('Cleaning up...');
  await this.page?.close();
  await this.context?.close();
  // await this.page?.close();
  // await this.context?.close();
});

// After(async function (scenario) {
//   if (scenario.result?.status === Status.FAILED) {
//     await this.captureScreenshot(scenario.pickle.name);
//   }
//   await this.cleanup();
//   await this.page?.close();
//   await this.context?.close();
// });

// AfterAll(async () => {
//   console.log('Closing browser...');
//   await browser.close();
// });

After(async function (scenario: ITestCaseHookParameter) {
  if (scenario.result?.status === Status.FAILED) {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-'); // e.g., 2025-04-27T18-48-00
      const screenshotPath = `./test-results/screenshots/${scenario.pickle.name}-${timestamp}.png`;

      try {
          const screenshot = await this.page!.screenshot({ path: screenshotPath, fullPage: true });
          await this.attach(screenshot, 'image/png'); // Attach to Cucumber report
          console.log(`Screenshot saved: ${screenshotPath}`);
          // await browser.close();
      } catch (error) {
          console.error('Failed to capture screenshot:', error);
          await this.page.close();
          await this.context.close();
  }
  }
});

AfterAll(async function () {
  if (browser) {
    await browser.close();
  }
});