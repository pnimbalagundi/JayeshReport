import { Page } from '@playwright/test';
import { expect } from '@playwright/test';
import { config } from '../test/config/config';
import { login_selectors } from '../test/pageobjects/login.page';
import { logger } from './logger';
import { setDefaultTimeout } from '@cucumber/cucumber';

setDefaultTimeout(80000);

export async function login(page: Page): Promise<boolean> {
  logger.info(`Navigating to ${config.baseUrl}`);
  await page.goto(config.baseUrl, {timeout: 100000, waitUntil: 'load',});
  logger.info('Clicking email field');
  await page.locator(login_selectors.loginUsernameEntry).click({ timeout: 60000 });
  logger.info(`Filling username: ${config.username}`);
  await page.locator(login_selectors.loginUsernameEntry).fill(config.username);
  logger.info('Pressing Tab to move to password field');
  await page.locator(login_selectors.loginUsernameEntry).press('Tab');
  logger.info('Filling password');
  await page.locator(login_selectors.loginPasswordEntry).fill(config.password);
  logger.info('Clicking Sign In button');
  await page.locator(login_selectors.loginButton).click({ timeout: 80000 });
  logger.info('Verifying login success (Business Unit Admin visible)');
  await expect(page.locator(login_selectors.dashboardHeader)).toBeVisible({ timeout: 80000 });
  logger.info('Login successful');
  return true;
}