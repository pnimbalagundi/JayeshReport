// import * as reporter from 'cucumber-html-reporter';
// import * as path from 'path';

// // Explicitly import and use the Options type
// const options: reporter.Options = {
//   theme: 'bootstrap', // Must be one of: "bootstrap", "hierarchy", "foundation", "simple"
//   jsonFile: path.join(__dirname, '../../reports/cucumber-report.json'),
//   output: path.join(__dirname, '../../reports/cucumber-report.html'),
//   reportSuiteAsScenarios: true,
//   launchReport: true,
//   metadata: {
//     'App Version': '1.0.0',
//     'Test Environment': 'Local',
//     'Browser': 'Chromium',
//     'Platform': 'Windows/Mac/Linux', // Adjust as needed
//     'Executed': 'Local'
//   }
// };

// reporter.generate(options);