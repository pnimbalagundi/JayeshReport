/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5038759689922481, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.75, 500, 1500, "Maker_Logsout-0"], "isController": false}, {"data": [0.625, 500, 1500, "Maker_Access_File_Review-0"], "isController": false}, {"data": [0.625, 500, 1500, "Maker_Logsout-1"], "isController": false}, {"data": [0.625, 500, 1500, "Checker_Submitsiffile-1"], "isController": false}, {"data": [0.75, 500, 1500, "Maker_Access_File_Review-1"], "isController": false}, {"data": [0.75, 500, 1500, "Checker_Submitsiffile-0"], "isController": false}, {"data": [0.625, 500, 1500, "Maker_Accepts_Salary-1"], "isController": false}, {"data": [0.75, 500, 1500, "Maker_Accepts_Salary-0"], "isController": false}, {"data": [0.0, 500, 1500, "Checker Transaction Controller"], "isController": true}, {"data": [0.5, 500, 1500, "Maker_Reviewfilebank"], "isController": false}, {"data": [0.5, 500, 1500, "Maker_Access_File_Review"], "isController": false}, {"data": [0.25, 500, 1500, "Checker_Submitsiffile"], "isController": false}, {"data": [0.5, 500, 1500, "Launch_Maker_App"], "isController": false}, {"data": [0.5, 500, 1500, "Checker_Launch_App"], "isController": false}, {"data": [0.75, 500, 1500, "Checker_Logout-0"], "isController": false}, {"data": [0.25, 500, 1500, "Checker_Logout"], "isController": false}, {"data": [0.6, 500, 1500, "Checker_Uploadsiffile-0"], "isController": false}, {"data": [0.7, 500, 1500, "Checker_Uploadsiffile-1"], "isController": false}, {"data": [0.375, 500, 1500, "Checker_Logout-1"], "isController": false}, {"data": [0.5, 500, 1500, "Maker_Reviewfilebank-1"], "isController": false}, {"data": [0.625, 500, 1500, "Maker_Reviewfilebank-0"], "isController": false}, {"data": [0.5, 500, 1500, "Checker_Uploads_File-0"], "isController": false}, {"data": [0.5, 500, 1500, "Checker_Uploadsiffile"], "isController": false}, {"data": [0.5, 500, 1500, "Checker_Uploads_File-1"], "isController": false}, {"data": [0.5, 500, 1500, "Maker_Accepts_Salary"], "isController": false}, {"data": [0.375, 500, 1500, "Maker_Logsout"], "isController": false}, {"data": [0.4, 500, 1500, "Checker_Login_to_App"], "isController": false}, {"data": [0.4, 500, 1500, "Checker_Uploads_File"], "isController": false}, {"data": [0.5, 500, 1500, "Login_Maker"], "isController": false}, {"data": [0.0, 500, 1500, "Maker Transaction Controller"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 121, 0, 0.0, 890.6942148760326, 331, 3455, 769.0, 1425.0, 1709.9999999999998, 3348.7400000000007, 2.0091657810839534, 18.992149361135098, 2.8525989950019928], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Maker_Logsout-0", 4, 0, 0.0, 534.25, 334, 756, 523.5, 756.0, 756.0, 756.0, 0.09345357693565721, 0.09080694243259661, 0.11590433858230924], "isController": false}, {"data": ["Maker_Access_File_Review-0", 4, 0, 0.0, 598.5, 458, 806, 565.0, 806.0, 806.0, 806.0, 0.09256259545517656, 0.0677044765585227, 0.09247220229555236], "isController": false}, {"data": ["Maker_Logsout-1", 4, 0, 0.0, 595.0, 440, 752, 594.0, 752.0, 752.0, 752.0, 0.09415087678004001, 1.1575087163116393, 0.07888813698952572], "isController": false}, {"data": ["Checker_Submitsiffile-1", 4, 0, 0.0, 875.0, 439, 1169, 946.0, 1169.0, 1169.0, 1169.0, 0.09597389510053266, 1.1504683226162484, 0.10487772325927348], "isController": false}, {"data": ["Maker_Access_File_Review-1", 4, 0, 0.0, 606.0, 420, 804, 600.0, 804.0, 804.0, 804.0, 0.09262046449162942, 1.114000777143585, 0.09524350498992754], "isController": false}, {"data": ["Checker_Submitsiffile-0", 4, 0, 0.0, 632.0, 427, 866, 617.5, 866.0, 866.0, 866.0, 0.09527212099559366, 0.07554781469572466, 0.10057535429319996], "isController": false}, {"data": ["Maker_Accepts_Salary-1", 4, 0, 0.0, 700.25, 444, 927, 715.0, 927.0, 927.0, 927.0, 0.09276868129319542, 1.114537794540563, 0.0935840310311239], "isController": false}, {"data": ["Maker_Accepts_Salary-0", 4, 0, 0.0, 518.0, 403, 611, 529.0, 611.0, 611.0, 611.0, 0.09285697704111243, 0.06791980058964181, 0.0909526835666365], "isController": false}, {"data": ["Checker Transaction Controller", 5, 0, 0.0, 7030.4, 3455, 8968, 7441.0, 8968.0, 8968.0, 8968.0, 0.08302062232258493, 5.861628880176336, 0.8421080077541261], "isController": true}, {"data": ["Maker_Reviewfilebank", 4, 0, 0.0, 1193.5, 1066, 1283, 1212.5, 1283.0, 1283.0, 1283.0, 0.09177469312836985, 1.1791121156934725, 0.19215326373752437], "isController": false}, {"data": ["Maker_Access_File_Review", 4, 0, 0.0, 1205.0, 1056, 1310, 1227.0, 1310.0, 1310.0, 1310.0, 0.09164852789552068, 1.169346610436476, 0.18580307022568449], "isController": false}, {"data": ["Checker_Submitsiffile", 4, 0, 0.0, 1507.5, 928, 2036, 1533.0, 2036.0, 2036.0, 2036.0, 0.09428403064230996, 1.2049756923983501, 0.20256334708308782], "isController": false}, {"data": ["Launch_Maker_App", 4, 0, 0.0, 770.25, 519, 1041, 760.5, 1041.0, 1041.0, 1041.0, 0.09328140668361279, 1.1181926435950653, 0.0919149798278958], "isController": false}, {"data": ["Checker_Launch_App", 5, 0, 0.0, 914.2, 458, 2017, 640.0, 2017.0, 2017.0, 2017.0, 0.08737134569346637, 1.0595994078407047, 0.07926560561448268], "isController": false}, {"data": ["Checker_Logout-0", 4, 0, 0.0, 707.5, 331, 1046, 726.5, 1046.0, 1046.0, 1046.0, 0.09573958831977022, 0.09302821325993298, 0.1190200155576831], "isController": false}, {"data": ["Checker_Logout", 4, 0, 0.0, 1662.5, 862, 2972, 1408.0, 2972.0, 2972.0, 2972.0, 0.09152061501853292, 1.2126928367958631, 0.19045940488720084], "isController": false}, {"data": ["Checker_Uploadsiffile-0", 5, 0, 0.0, 572.0, 471, 840, 515.0, 840.0, 840.0, 840.0, 0.09051903615330303, 0.06612132719010808, 0.12089241586255589], "isController": false}, {"data": ["Checker_Uploadsiffile-1", 5, 0, 0.0, 667.2, 411, 942, 671.0, 942.0, 942.0, 942.0, 0.09068320728367521, 1.0909437798121044, 0.10083193341132089], "isController": false}, {"data": ["Checker_Logout-1", 4, 0, 0.0, 954.5, 530, 1926, 681.0, 1926.0, 1926.0, 1926.0, 0.09367023394140928, 1.150158873498349, 0.07848541086106361], "isController": false}, {"data": ["Maker_Reviewfilebank-1", 4, 0, 0.0, 676.25, 611, 750, 672.0, 750.0, 750.0, 750.0, 0.09274287039183862, 1.1204543313818687, 0.09862986900069556], "isController": false}, {"data": ["Maker_Reviewfilebank-0", 4, 0, 0.0, 516.25, 454, 567, 522.0, 567.0, 567.0, 567.0, 0.09312070771737865, 0.07138648003724829, 0.09593979164241649], "isController": false}, {"data": ["Checker_Uploads_File-0", 5, 0, 0.0, 595.0, 511, 747, 522.0, 747.0, 747.0, 747.0, 0.09101831288455238, 0.06675268845341684, 0.09133829914078713], "isController": false}, {"data": ["Checker_Uploadsiffile", 5, 0, 0.0, 1239.2, 996, 1413, 1251.0, 1413.0, 1413.0, 1413.0, 0.08985048878665901, 1.1465589228274151, 0.21990556152062965], "isController": false}, {"data": ["Checker_Uploads_File-1", 5, 0, 0.0, 679.0, 598, 780, 628.0, 780.0, 780.0, 780.0, 0.09086613600843238, 1.0931444623905062, 0.09384768109620906], "isController": false}, {"data": ["Maker_Accepts_Salary", 4, 0, 0.0, 1218.75, 1002, 1428, 1222.5, 1428.0, 1428.0, 1428.0, 0.0919096528112865, 1.171444173502447, 0.18274223937869075], "isController": false}, {"data": ["Maker_Logsout", 4, 0, 0.0, 1129.75, 774, 1509, 1118.0, 1509.0, 1509.0, 1509.0, 0.09250265945145923, 1.2271281754428565, 0.19223208917256374], "isController": false}, {"data": ["Checker_Login_to_App", 5, 0, 0.0, 1066.0, 605, 1611, 1105.0, 1611.0, 1611.0, 1611.0, 0.08958325868061777, 1.0864594624556563, 0.12261708531909557], "isController": false}, {"data": ["Checker_Uploads_File", 5, 0, 0.0, 1274.4, 1110, 1522, 1150.0, 1522.0, 1522.0, 1522.0, 0.09001224166486643, 1.1488867173435586, 0.18329445929646432], "isController": false}, {"data": ["Login_Maker", 4, 0, 0.0, 720.25, 550, 899, 716.0, 899.0, 899.0, 899.0, 0.09271492478501726, 1.124938069327585, 0.1267586862295158], "isController": false}, {"data": ["Maker Transaction Controller", 4, 0, 0.0, 6237.5, 5781, 6878, 6145.5, 6878.0, 6878.0, 6878.0, 0.0837573549427309, 6.343699451127583, 0.8828057928680613], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 121, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
