// import { Browser, Page, chromium } from 'playwright';
// import winston from 'winston';

// export class Base {
//   private browser: Browser | null = null;
//   private page: Page | null = null;

//   async setup() {
//     this.browser = await chromium.launch({ headless: true });
//     this.page = await this.browser.newPage();
//     return this.page;
//   }

//   readonly logger = winston.createLogger({
//     level: 'info',
//     format: winston.format.combine(
//       winston.format.timestamp(),
//       winston.format.printf(({ timestamp, level, message }) => `${timestamp} [${level}]: ${message}`)
//     ),
//     transports: [
//       new winston.transports.Console(),
//       new winston.transports.File({ filename: 'test.log' }),
//     ],
//   });

//   async captureScreenshotOnFailure(scenarioName: string) {
//     if (this.page && !this.page.isClosed()) {
//       const sanitizedName = scenarioName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
//       const screenshotPath = `screenshots/${sanitizedName}_${Date.now()}.png`;
//       await this.page.screenshot({ path: screenshotPath, fullPage: true });
//       console.log(`Screenshot saved to: ${screenshotPath}`);
//     }
//   }

//   async teardown() {
//     if (this.page && !this.page.isClosed()) {
//       await this.page.close();
//     }
//     if (this.browser) {
//       await this.browser.close();
//     }
//   }

//   getPage(): Page {
//     if (!this.page) throw new Error('Page not initialized. Call setup() first.');
//     return this.page;
//   }
// }

// base.ts
import { Browser, chromium, Page } from 'playwright';
import * as winston from 'winston';

export class Base {
  private browser: Browser | null = null;
  private page: Page | null = null;
  private logger: winston.Logger;

  constructor() {
    this.logger = winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(({ timestamp, level, message }) => `${timestamp} [${level}]: ${message}`)
      ),
      transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'test.log' }),
      ],
    });
  }

  async setup(headless = true): Promise<Page> {
    if (!this.page || this.page.isClosed()) {
      this.browser = await chromium.launch({ headless });
      this.page = await this.browser.newPage();
      this.logger.info('Browser and page initialized');
    }
    return this.page;
  }

  async screenshotOnFailure(scenarioName: string): Promise<void> {
    if (this.page && !this.page.isClosed()) {
      const path = `screenshots/${scenarioName.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.png`;
      await this.page.screenshot({ path, fullPage: true });
      this.logger.info(`Screenshot saved to: ${path}`);
    }
  }

  async teardown(): Promise<void> {
    if (this.page && !this.page.isClosed()) await this.page.close();
    if (this.browser) await this.browser.close();
    this.logger.info('Browser and page closed');
  }

  async captureScreenshotOnFailure(scenarioName: string) {
    if (this.page && !this.page.isClosed()) {
      const sanitizedName = scenarioName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
      const screenshotPath = `screenshots/${sanitizedName}_${Date.now()}.png`;
      await this.page.screenshot({ path: screenshotPath, fullPage: true });
      console.log(`Screenshot saved to: ${screenshotPath}`);
    }
  }

  getPage(): Page {
    if (!this.page) throw new Error('Page not initialized. Call setup() first.');
    return this.page;
  }
}