import { setWorldConstructor } from '@cucumber/cucumber';
import { Base } from './base';

class CustomWorld {
  private base: Base;

  constructor() {
    this.base = new Base();
  }

  async getPage() {
    return await this.base.setup();
  }

  async captureScreenshot(scenarioName: string) {
    await this.base.captureScreenshotOnFailure(scenarioName);
  }

  async cleanup() {
    await this.base.teardown();
  }
}

setWorldConstructor(CustomWorld);