import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { config } from '../config/config';
import { login_selectors } from '../pageobjects/login.page';
import { logger } from '../../utils/logger';

// setDefaultTimeout(80000);

// const logger = winston.createLogger({ /* ... */ }); // Outside class, as a module constant

  Given('user navigates to application', async function (this: CustomWorld) {
    setDefaultTimeout(40000);
    await this.page!.goto(config.baseUrl,{ timeout: 100000 });
    return true;
  });

  When('User enters username {string}', async function (userName:string) {
    logger.info('User enters Username started');
    await this.page!.locator(login_selectors.loginUsernameEntry).click({ timeout: 100000 });
    await this.page!.locator(login_selectors.loginUsernameEntry).fill(userName);
    await this.page!.locator(login_selectors.loginUsernameEntry).press('Tab');
    logger.info('User enters Username Ended');
    return true;
  });

  When('User enters password {string}', async function (password:string) {
    logger.info('User enters Password started');
    await this.page!.locator(login_selectors.loginPasswordEntry).fill(password ,{ timeout: 100000 });
    logger.info('User enters Password ended');
    return true;
  });

  Then('user clicks on Submit button', async function () {
    logger.info('User clcks Submit started');
    await this.page!.locator(login_selectors.loginButton).click({ timeout: 80000 });
    logger.info('User clcks Submit ended');
    return true;
  });

