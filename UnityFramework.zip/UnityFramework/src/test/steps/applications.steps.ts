import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { login } from '../../utils/loginUtils';
import { logger } from '../../utils/logger';
import { app_selectors } from '../pageobjects/applications.page';
import { config } from '../config/config';
import { login_selectors } from '../pageobjects/login.page';

setDefaultTimeout(80000);
// const logger = winston.createLogger({ /* ... */ }); // Outside class, as a module constant

 Given('Checker User navigates to application', async function (this: CustomWorld) {
//  Given('login to the application', async function (this: CustomWorld,userName:string,password:string) {
  logger.info('Checker Starting login process');
  // await login(this.page!);
  await this.page!.goto(config.baseUrl, {timeout: 100000, waitUntil: 'load',});
  await this.page!.locator(login_selectors.loginUsernameEntry).click({ timeout: 100000 });
  await this.page!.locator(login_selectors.loginUsernameEntry).fill('Admin3');
  await this.page!.locator(login_selectors.loginUsernameEntry).press('Tab');
  await this.page!.locator(login_selectors.loginPasswordEntry).fill('P@$$w0rd');
  await this.page!.locator(login_selectors.loginButton).click({ timeout: 80000 });
  await expect(this.page!.locator('#SvgjsPath1032')).toBeVisible({ timeout: 80000 });
  logger.info('Checker Login step completed');
});

Given('Maker User navigates to application', async function (this: CustomWorld) {
    logger.info('Maker Starting login process');
    await this.page!.goto(config.baseUrl, {timeout: 100000, waitUntil: 'load',});
    await this.page!.locator(login_selectors.loginUsernameEntry).click({ timeout: 100000 });
    await this.page!.locator(login_selectors.loginUsernameEntry).fill('Admin4');
    await this.page!.locator(login_selectors.loginUsernameEntry).press('Tab');
    await this.page!.locator(login_selectors.loginPasswordEntry).fill('P@$$w0rd');
    await this.page!.locator(login_selectors.loginButton).click({ timeout: 80000 });
    await expect(this.page!.locator('#SvgjsPath1021')).toBeVisible({ timeout: 80000 });   
    logger.info('Maker Login step completed');
  });

  
Given('Verify that Employer Master Page is displayed Successfully', async function (this: CustomWorld) {
  logger.info('TC_WPS_SAL_01 - Verify that Employer Master Page is accessable Successfully started');
  await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.wpsLink).click();
  await this.page!.getByText(app_selectors.maintenanceLink).first().click();
  await this.page!.locator(app_selectors.wpsEmployerMaster).click();
  await expect(this.page!.locator(app_selectors.createEmployeLink)).toContainText('Employer Create');
  await expect(this.page!.locator(app_selectors.employerMasterHeader)).toBeVisible();
  await this.page!.locator(app_selectors.employerMasterHeader).click();
  logger.info('TC_WPS_SAL_01 - Verify that Employer Master Page Ended Successfully');
  return true;
});

Given('Verify that Salary Page is displayed Successfully', async function (this: CustomWorld) {
  logger.info('Verify that Salary Page is accessable Successfully started');
  await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.wpsLink).click({ timeout: 30000 });
  await this.page!.getByText(app_selectors.wpsSalaryLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.uploadSalarySideMenu).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.salaryHeader)).toContainText('Salary File Upload');
  logger.info('Verify that Salary Page Ended Successfully');
  return true;
});

Given('Verify that Review Salary Page is displayed Successfully', async function (this: CustomWorld) {
  logger.info('Verify that Review Salary Page is accessable Successfully started');
  await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.wpsLink).click({ timeout: 30000 });
  await this.page!.getByText(app_selectors.wpsSalaryLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.reviewSalarySideMenu).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.reviewFileHeader)).toContainText('Review file');
  logger.info('Verify that Review Salary Page Ended Successfully');
  return true;
});

When('Checker user creates Employer with valid data {string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_02 - Verify User enters Employer Data Successfully started');
  await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).click();
  await this.page!.locator(app_selectors.employerIDTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerIDTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerNameTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerNameTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId);
  await this.page!.locator(app_selectors.addButton).click();
  await this.page!.locator(app_selectors.employerTrdLicTextBox).click();
  await this.page!.locator(app_selectors.employerTrdLicTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerPhNoData).click();
  await this.page!.locator(app_selectors.employerPhNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerFaxNoData).click();
  await this.page!.locator(app_selectors.employerFaxNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerPOBoxData).click();
  await this.page!.locator(app_selectors.employerPOBoxData).fill('1');
  await this.page!.locator(app_selectors.employerAdd1Data).click();
  await this.page!.locator(app_selectors.employerAdd1Data).fill(employerId);
  await this.page!.getByText('Economic Activity None').click();
  await this.page!.locator(app_selectors.EmirateCodeTextBox).selectOption('1');  
  await this.page!.locator(app_selectors.Activity).selectOption('2');
  await this.page!.locator(app_selectors.contactPerson).click();
  await this.page!.locator(app_selectors.contactPerson).fill('Tester');
  await this.page!.locator(app_selectors.ContactPersonNbr).click();
  await this.page!.locator(app_selectors.ContactPersonNbr).fill('1234567890');
  await this.page!.locator(app_selectors.FixedCharge).click();
  await this.page!.locator(app_selectors.FixedCharge).fill('10');
  await this.page!.locator(app_selectors.VariableCharge).click();
  await this.page!.locator(app_selectors.VariableCharge).fill('1');
  await this.page!.locator(app_selectors.ChkPost).click();
  logger.info('TC_WPS_SAL_05 - Verify added account number associated with employer Id on Employ Master started');
  await expect(this.page!.locator(app_selectors.accountNumberBody)).toContainText(employerId);
  logger.info('TC_WPS_SAL_05 - Verify added account number associated with employer Id on Employ Master ended');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible();
  await this.page!.locator(app_selectors.saveButton).click();
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer records saved successfully.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_02 - Verify that user can be able to add New Employer Master record Ended Successfully');
  return true;
});

When('Checker user edits Employer with valid data {string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_04 - Verify that user can be able to edit the employer master data started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click();
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click();
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  await expect(this.page!.locator(app_selectors.editLink)).toBeVisible();
  await this.page!.locator(app_selectors.editLink).click();
  await this.page!.locator(app_selectors.employerPhNoData1).fill('1234567890');
  await this.page!.locator(app_selectors.employerAdd2Data).fill('address2');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible();
  await this.page!.locator(app_selectors.saveButton).click();
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer records saved successfully.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_04 - Verify that user can be able to edit the employer master data Ended Successfully');
  return true;
});

When('User verify Pagination Functionality on Employer Master Page', async function (this: CustomWorld) {
  logger.info('TC_WPS_SAL_06 - User verify Pagination Functionality on Employer Master Page started Successfully');
  await this.page!.locator(app_selectors.employerMasterHeader).click();
  await expect(this.page!.locator(app_selectors.clientDataInfo)).toBeVisible({timeout:80000});
  logger.info('validate page 1 started');
  await expect(this.page!.locator(app_selectors.clientDataInfo)).toContainText('Showing 1 to 10 of ');
  await expect(this.page!.locator(app_selectors.paginationPage)).toBeVisible();
  await expect(this.page!.locator(app_selectors.paginationPage)).toContainText('1');
  logger.info('validate page 1 ended');
  await this.page!.locator(app_selectors.secondPageLink).click();
  logger.info('validate page 2 started');
  await expect(this.page!.locator(app_selectors.clientDataInfo)).toContainText('Showing 11 to 20 of ');
  await expect(this.page!.locator(app_selectors.paginationPage)).toContainText('2');
  logger.info('validate page 2 ended');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_06 - User verify Pagination Functionality on Employer Master Page Ended Successfully');
  return true;
});


When('User verify EmpId, Name and Iban on Employer Master Page {string}', async function (this: CustomWorld, employerId:string) {
  logger.info('TC_08_09_10_Checker User verify EmpId, Name and Iban on Employer Master Page started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click();
  logger.info('User verify EmpId started Successfully');
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click();
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  logger.info('User verify EmpId ended Successfully');
  await this.page!.locator(app_selectors.clearFilterButton).click();
  logger.info('User verify Emp Name started Successfully');
  await this.page!.locator(app_selectors.employerNameSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click();
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  logger.info('User verify Emp Name ended Successfully'); 
  await this.page!.locator(app_selectors.clearFilterButton).click();
  logger.info('User verify Emp IBan started Successfully');
  await this.page!.locator(app_selectors.employerIBanSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click();
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  logger.info('User verify Emp IBan ended Successfully');  
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_08_09_10_Checker User verify EmpId, Name and Iban on Employer Master Page Ended Successfully');
  return true;
});


When('Checker user reedits Employer with valid data {string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_11 - Verify edit case for already sent employer approval case on Employer Master page started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click();
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click();
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  await expect(this.page!.locator(app_selectors.editLink)).toBeVisible();
  await this.page!.locator(app_selectors.editLink).click();
  await this.page!.locator(app_selectors.employerPhNoData1).fill('1234567890');
  await this.page!.locator(app_selectors.employerAdd2Data).fill('address2');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible();
  await this.page!.locator(app_selectors.saveButton).click();
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Transaction already in workflow.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_04 - Verify that user can be able to edit the employer master data Ended Successfully');
  return true;
});


When('Checker user creates Employer with valid multiple account data {string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_17 - Verify User creates Employer with valid multiple account data Successfully started');
  await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).click();
  await this.page!.locator(app_selectors.employerIDTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerIDTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerNameTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerNameTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId);
  await this.page!.locator(app_selectors.addButton).click();
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'1');
  await this.page!.locator(app_selectors.addButton).click();
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'2');
  await this.page!.locator(app_selectors.addButton).click();
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'3');
  await this.page!.locator(app_selectors.addButton).click();
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'4');
  await this.page!.locator(app_selectors.addButton).click();
  await this.page!.locator(app_selectors.employerTrdLicTextBox).click();
  await this.page!.locator(app_selectors.employerTrdLicTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerPhNoData).click();
  await this.page!.locator(app_selectors.employerPhNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerFaxNoData).click();
  await this.page!.locator(app_selectors.employerFaxNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerPOBoxData).click();
  await this.page!.locator(app_selectors.employerPOBoxData).fill('1');
  await this.page!.locator(app_selectors.employerAdd1Data).click();
  await this.page!.locator(app_selectors.employerAdd1Data).fill(employerId);
  await this.page!.getByText('Economic Activity None').click();
  await this.page!.locator(app_selectors.EmirateCodeTextBox).selectOption('1');  
  await this.page!.locator(app_selectors.Activity).selectOption('2');
  await this.page!.locator(app_selectors.contactPerson).click();
  await this.page!.locator(app_selectors.contactPerson).fill('Tester');
  await this.page!.locator(app_selectors.ContactPersonNbr).click();
  await this.page!.locator(app_selectors.ContactPersonNbr).fill('1234567890');
  await this.page!.locator(app_selectors.FixedCharge).click();
  await this.page!.locator(app_selectors.FixedCharge).fill('10');
  await this.page!.locator(app_selectors.VariableCharge).click();
  await this.page!.locator(app_selectors.VariableCharge).fill('1');
  await this.page!.locator(app_selectors.ChkPost).click();
  logger.info('TC_WPS_SAL_23 - Verify that one account should be default account in Employer Master started');
  await expect(this.page!.locator(app_selectors.accountNumberBody)).toContainText(employerId);
  logger.info('TC_WPS_SAL_23 - Verify that one account should be default account in Employer Master ended');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible();
  await this.page!.locator(app_selectors.saveButton).click();
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer records saved successfully.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_17 - Verify user creates Employer with valid multiple account data Ended Successfully');
  return true;
});


When('User verifies Emirates and Activity field dropdown values', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_20_21 - Verify User Emirates and Activity data started Successfully');
await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await expect(this.page!.locator(app_selectors.validateEmirates)).toBeVisible();
await expect(this.page!.locator(app_selectors.validateEmirates)).toContainText('--Select-- Dubai Sharjah Abudhabi Fujairah Ras Al Khamah Umm Al Quwain Ajman');
await expect(this.page!.locator(app_selectors.validateActivity)).toContainText('None Banking Construction Retail Trading');
logger.info('TC_WPS_SAL_20_21 - Verify user Emirates and Activity data Ended Successfully');
return true;
});

When('User uploads salary file {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('TC_WPS_SAL_13 - Verify User upload salary file started Successfully');
  const fileInput = await this.page!.locator(app_selectors.fileInput);
  const filePath = dataFile;
  await fileInput.setInputFiles(filePath);
  await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible();
  await this.page!.getByRole('button', { name: 'Go' }).click();
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.locator(app_selectors.fileSubmitButton).click({timeout:80000});
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText(app_selectors.validateUploadMessage);
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_13 - Verify User upload salary file Ended Successfully');
  return true;
  });

  When('User uploads error salary file {string}', async function (this: CustomWorld, dataFile:string) {
    logger.info('TC_WPS_SAL_29 - Verify User upload error salary file started Successfully');
    const fileInput = await this.page!.locator(app_selectors.fileInput);
    const filePath = dataFile;
    await fileInput.setInputFiles(filePath);
    await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible();
    await this.page!.getByRole('button', { name: 'Go' }).click();
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await expect(this.page!.locator(app_selectors.validateErrorTitle)).toBeVisible();
    await expect(this.page!.locator(app_selectors.validateErrorTitle)).toContainText('Error');
    await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('The file format you uploaded is not supported.');
    await this.page!.waitForLoadState("networkidle");
    logger.info('TC_WPS_SAL_29 - Verify User upload error salary file Ended Successfully');
    return true;
    });

    
    When('User tries to change uploaded salary file {string}', async function (this: CustomWorld, dataFile:string) {
      logger.info('TC_WPS_SAL_31 - Verify User changes uploaded salary file started Successfully');
      const fileInput = await this.page!.locator(app_selectors.fileInput);
      const filePath = dataFile;
      await fileInput.setInputFiles(filePath);
      await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible();
      await this.page!.getByRole('button', { name: 'Go' }).click();
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.locator(app_selectors.changeButton).click();
      await expect(this.page!.locator(app_selectors.validateErrorTitle)).toBeVisible();
      await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Salary file deleted successfully.');
      await this.page!.waitForLoadState("networkidle");
      logger.info('TC_WPS_SAL_31 - Verify User changes uploaded salary file Ended Successfully');
      return true;
      });

      When('User tries to cancel uploaded salary file {string}', async function (this: CustomWorld, dataFile:string) {
        logger.info('TC_WPS_SAL_32 - Verify User cancels uploaded salary file started Successfully');
        const fileInput = await this.page!.locator(app_selectors.fileInput);
        const filePath = dataFile;
        await fileInput.setInputFiles(filePath);
        await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible();
        await this.page!.getByRole('button', { name: 'Go' }).click();
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.locator(app_selectors.cancelButton).click();
        await this.page!.waitForLoadState("networkidle");
        logger.info('TC_WPS_SAL_32 - Verify User cancels uploaded salary file Ended Successfully');
        return true;
        });
  
        When('User Reviews uploaded salary file details', async function (this: CustomWorld, dataFile:string) {
          logger.info('TC_WPS_SAL_40 - Verify that user can be able to view record details page by clicking reference number started Successfully');
          await expect(this.page!.locator('//td[class="sorting_1"]')).toBeVisible();
          await this.page!.locator('//td[class="sorting_1"]').first().click();
          // await this.page!.getByRole('link', { name: 'SIF2504270002644' }).click();
          await expect(this.page!.locator('#kt_app_content_container')).toContainText('Apr 2025');
          await expect(this.page!.locator('#kt_app_content_container')).toContainText('165,000.00');
          await expect(this.page!.locator('#kt_app_content_container')).toContainText('ALDARMAK008');
          await expect(this.page!.locator('thead')).toContainText('00446229636376');
          await expect(this.page!.locator('thead')).toContainText('002510101');
          await expect(this.page!.locator('thead')).toContainText('AE760860953926551097745');
          logger.info('TC_WPS_SAL_40 - Verify that user can be able to view record details page by clicking reference number Ended Successfully');
          return true;
          });
  