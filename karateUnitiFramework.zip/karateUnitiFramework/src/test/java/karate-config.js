function fn() {
  var configData = karate.read("classpath:config.json");
  
  var env = karate.env; // get system property 'karate.env'
  // karate.log('karate.env system property was:', env);
  // if (!env) {
  //   env = 'dev';
  // }
  // var config = {
  //   env: env,
  //   myVarName: 'someValue',
  // }
  if (env == 'develop') {
    // customize
    // e.g. config.foo = 'bar';
    b2cCheckerUsername = configData.B2C_CHECKER_USERNAME_DEV,
    b2cCheckerPassword = configData.B2C_CHECKER_PASSWORD_DEV,
    b2cMakerUsername = configData.B2C_MAKER_USERNAME_DEV,
    b2cMakerPassword = configData.B2C_MAKER_PASSWORD_DEV,
    b2cTokenUrl = configData.B2C_TOKEN_URL_DEV
  } else if (env == 'e2e') {
    // customize
    b2cUsername = configData.B2C_USERNAME_RELEASE,
    b2cPassword = configData.B2C_PASSWORD_RELEASE,
    b2cTokenUrl = configData.B2C_TOKEN_URL_RELEASE
  }

 var config = {
    baseUrl: configData.BASE_URL,
    b2cTokenUrl: configData.B2C_TOKEN_URL_DEV,
    tokenUrl: configData.B2C_TOKEN_URL,
 }

  return config;
}