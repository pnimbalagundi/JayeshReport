package api.utilities;

import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.util.encoders.Hex;

public class EncryptionUtils {

    public static String sha256Hash(String input) {
        SHA256Digest digest = new SHA256Digest();
        byte[] inputBytes = input.getBytes();
        digest.update(inputBytes, 0, inputBytes.length);
        byte[] outputBytes = new byte[digest.getDigestSize()];
        digest.doFinal(outputBytes, 0);
        return new String(Hex.encode(outputBytes));
    }

    // You can add other encryption methods here (AES, etc.)
}